(function() {
  const IDLE_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes
  const WARNING_MS = 4 * 60 * 1000; // 4 minutes

  let idleTimer = null;
  let warningTimer = null;
  let modalOverlay = null;

  function createModal() {
    if (modalOverlay) return;
    
    modalOverlay = document.createElement('div');
    modalOverlay.style.position = 'fixed';
    modalOverlay.style.top = '0';
    modalOverlay.style.left = '0';
    modalOverlay.style.width = '100%';
    modalOverlay.style.height = '100%';
    modalOverlay.style.background = 'rgba(0,0,0,0.6)';
    modalOverlay.style.display = 'none';
    modalOverlay.style.alignItems = 'center';
    modalOverlay.style.justifyContent = 'center';
    modalOverlay.style.zIndex = '99999';
    modalOverlay.style.backdropFilter = 'blur(3px)';

    const modalBox = document.createElement('div');
    modalBox.style.background = '#fff';
    modalBox.style.padding = '35px 30px';
    modalBox.style.borderRadius = '16px';
    modalBox.style.textAlign = 'center';
    modalBox.style.boxShadow = '0 20px 40px rgba(0,0,0,0.2)';
    modalBox.style.maxWidth = '400px';
    modalBox.style.width = '90%';

    const icon = document.createElement('div');
    icon.innerHTML = '<svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
    icon.style.marginBottom = '15px';

    const title = document.createElement('h3');
    title.textContent = 'Session Expiring Soon';
    title.style.margin = '0 0 10px 0';
    title.style.color = '#1e293b';
    title.style.fontFamily = 'Outfit, sans-serif';
    title.style.fontSize = '1.4rem';

    const desc = document.createElement('p');
    desc.textContent = 'You have been inactive for a while. For your security, you will be automatically logged out in 1 minute. Click below to stay logged in.';
    desc.style.color = '#64748b';
    desc.style.marginBottom = '25px';
    desc.style.fontSize = '0.95rem';
    desc.style.lineHeight = '1.5';
    desc.style.fontFamily = 'Outfit, sans-serif';

    const btn = document.createElement('button');
    btn.textContent = 'Stay Logged In';
    btn.style.padding = '12px 24px';
    btn.style.background = '#0f172a';
    btn.style.color = '#fff';
    btn.style.border = 'none';
    btn.style.borderRadius = '8px';
    btn.style.cursor = 'pointer';
    btn.style.fontWeight = '600';
    btn.style.fontFamily = 'Outfit, sans-serif';
    btn.style.fontSize = '1rem';
    btn.style.transition = 'background 0.2s';
    
    btn.onmouseover = () => btn.style.background = '#334155';
    btn.onmouseout = () => btn.style.background = '#0f172a';
    
    btn.addEventListener('click', () => {
      hideWarning();
      resetTimers();
    });

    modalBox.appendChild(icon);
    modalBox.appendChild(title);
    modalBox.appendChild(desc);
    modalBox.appendChild(btn);
    modalOverlay.appendChild(modalBox);

    document.body.appendChild(modalOverlay);
  }

  function showWarning() {
    createModal();
    modalOverlay.style.display = 'flex';
  }

  function hideWarning() {
    if (modalOverlay) {
      modalOverlay.style.display = 'none';
    }
  }

  function logoutUser() {
    hideWarning();
    
    // Call the respective portal's logout function if available
    if (typeof handleLogout === 'function') {
      handleLogout();
    } else if (typeof handleAdminLogout === 'function') {
      handleAdminLogout();
    } else if (typeof handleAccountsLogout === 'function') {
      handleAccountsLogout();
    } else {
      // Fallback
      localStorage.removeItem('vendorUser');
      localStorage.removeItem('vendorCompany');
      localStorage.removeItem('adminUser');
      localStorage.removeItem('accountsUser');
      window.location.href = window.location.pathname.includes('/pages/') ? 'login.html' : 'pages/login.html';
    }
  }

  function resetTimers() {
    clearTimeout(warningTimer);
    clearTimeout(idleTimer);
    hideWarning();

    warningTimer = setTimeout(showWarning, WARNING_MS);
    idleTimer = setTimeout(logoutUser, IDLE_TIMEOUT_MS);
  }

  // Listen to user activity
  const events = ['mousemove', 'keydown', 'scroll', 'click', 'touchstart'];
  events.forEach(evt => {
    document.addEventListener(evt, () => {
      // Only reset the timer if the warning modal is NOT shown. 
      // If it is shown, the user must explicitly click "Stay Logged In"
      if (!modalOverlay || modalOverlay.style.display === 'none') {
        resetTimers();
      }
    }, { passive: true });
  });

  // Start timers immediately upon script load
  resetTimers();
})();
