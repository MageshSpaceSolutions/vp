// Admin Auth Check
const currentAdminUser = localStorage.getItem('adminUser');
if (!currentAdminUser) {
  window.location.href = '../index.html';
}


// Global XSS Mitigation
function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


function handleAdminLogout() {
  localStorage.removeItem('adminUser');
  window.location.href = '../index.html';
}

// Format Currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
}

// Get Status Class
function getStatusClass(status) {
  switch (status.toLowerCase()) {
    case 'paid': return 'status-paid';
    case 'approved': return 'status-approved';
    default: return 'status-pending';
  }
}

function navigateTo(pageId) {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  document.querySelector(`.nav-item[data-page="${pageId}"]`)?.classList.add('active');

  document.querySelectorAll('.page').forEach(el => el.classList.remove('active'));
  document.getElementById(`page-${pageId}`)?.classList.add('active');

  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.remove('open');
  }

  if (pageId === 'all-bills') renderAdminData();
  if (pageId === 'vendors') renderVendors();
  if (pageId === 'activity') renderActivityLogs();
  if (pageId === 'settings') renderAccountsUsers();
}

function openPaymentModal(billId, vendorCompany) {
  const bill = window.allBills.find(b => b.id === billId && b.vendorCompany === vendorCompany);
  if (!bill) return;

  let modal = document.getElementById('paymentModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'paymentModal';
    modal.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center; z-index:1000;';
    document.body.appendChild(modal);
  }
  
  let paymentsHtml = bill.payments && bill.payments.length > 0 
    ? bill.payments.map(p => `
        <tr>
          <td>${p.date}</td>
          <td>${formatCurrency(p.amount)}</td>
          <td>${p.reference}</td>
          <td>
            <button onclick="editPaymentEntry('${p.id}', '${escapeHTML(bill.vendorCompany)}', '${p.date}', '${p.amount}', '${p.reference}')" style="background:var(--secondary); padding:2px 6px; font-size:0.75rem; border:none; border-radius:4px; color:white; cursor:pointer;">Edit</button>
            <button onclick="deletePaymentEntry('${p.id}', '${escapeHTML(bill.vendorCompany)}')" style="background:var(--danger); padding:2px 6px; font-size:0.75rem; border:none; border-radius:4px; color:white; cursor:pointer;">Del</button>
          </td>
        </tr>
      `).join('')
    : `<tr><td colspan="4" style="text-align:center; color:var(--text-muted);">No payments recorded yet.</td></tr>`;

  modal.innerHTML = `
    <div style="background:var(--surface); padding:24px; border-radius:12px; width:500px; max-width:90%; max-height:90vh; overflow-y:auto;">
      <h3 style="margin-bottom:16px;">Payments for Invoice: ${escapeHTML(bill.id)}</h3>
      <table class="data-table">
        <thead><tr><th>Date</th><th>Amount</th><th>Ref / Txn ID</th><th>Actions</th></tr></thead>
        <tbody>${paymentsHtml}</tbody>
      </table>
      
      <h4 id="paymentFormTitle" style="margin-top:24px; border-top:1px solid var(--border); padding-top:16px;">Add New Payment</h4>
      <form id="paymentForm" onsubmit="submitPayment(event, '${escapeHTML(bill.id)}', '${escapeHTML(bill.vendorCompany)}')" style="display:flex; flex-direction:column; gap:12px; margin-top:12px;">
        <input type="date" id="payDate" required style="padding:10px; border:1px solid var(--border); border-radius:8px;">
        <input type="number" step="0.01" id="payAmt" placeholder="Amount (₹)" required style="padding:10px; border:1px solid var(--border); border-radius:8px;">
        <input type="text" id="payRef" placeholder="Reference / Txn ID (Optional)" style="padding:10px; border:1px solid var(--border); border-radius:8px;">
        <div style="display:flex; gap:12px; margin-top:12px;">
          <button type="submit" id="paymentSubmitBtn" class="btn-primary" style="flex:1;">Save Payment</button>
          <button type="button" class="btn-primary" style="flex:1; background:var(--text-muted);" onclick="document.getElementById('paymentModal').style.display='none'">Close</button>
        </div>
      </form>
    </div>
  `;
  modal.style.display = 'flex';
}

function editPaymentEntry(paymentId, vendorCompany, oldDate, oldAmt, oldRef) {
  document.getElementById('payDate').value = oldDate;
  document.getElementById('payAmt').value = oldAmt;
  document.getElementById('payRef').value = oldRef !== 'undefined' ? oldRef : '';
  document.getElementById('paymentFormTitle').innerText = 'Edit Payment';
  document.getElementById('paymentSubmitBtn').innerText = 'Update Payment';
  document.getElementById('paymentForm').onsubmit = (e) => submitEditPayment(e, paymentId, vendorCompany);
}

async function submitEditPayment(e, paymentId, vendorCompany) {
  e.preventDefault();
  const date = document.getElementById('payDate').value;
  const amt = parseFloat(document.getElementById('payAmt').value);
  const ref = document.getElementById('payRef').value;
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/payments/${encodeURIComponent(paymentId)}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: vendorCompany, date: date, amount: amt, reference: ref })
    });
    if (response.ok) {
      document.getElementById('paymentModal').style.display = 'none';
      renderAdminData();
    } else {
      alert("Failed to update payment.");
    }
  } catch (err) {
    alert("Connection error");
  }
}

async function deletePaymentEntry(paymentId, vendorCompany) {
  if (!confirm("Are you sure you want to delete this payment?")) return;
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/payments/${encodeURIComponent(paymentId)}`, {
      method: 'DELETE',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: vendorCompany })
    });
    if (response.ok) {
      document.getElementById('paymentModal').style.display = 'none';
      renderAdminData();
    } else {
      alert("Failed to delete payment.");
    }
  } catch (err) {
    alert("Connection error");
  }
}

async function submitPayment(e, billId, vendorCompany) {
  e.preventDefault();
  const date = document.getElementById('payDate').value;
  const amt = parseFloat(document.getElementById('payAmt').value);
  const ref = document.getElementById('payRef').value;
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/bills/${encodeURIComponent(billId)}/payments`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: vendorCompany, date: date, amount: amt, reference: ref })
    });
    if (response.ok) {
      document.getElementById('paymentModal').style.display = 'none';
      renderAdminData();
    } else {
      alert("Failed to add payment.");
    }
  } catch (err) {
    alert("Connection error");
  }
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// Update Bill Status
async function updateBillStatus(billId, vendorCompany, newStatus) {
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/bills/${encodeURIComponent(billId)}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: vendorCompany, status: newStatus })
    });
    if (response.ok) {
      renderAdminData();
    } else {
      alert('Failed to update status.');
    }
  } catch (err) {
    alert('Could not connect to backend server.');
  }
}

// Delete Bill
async function deleteBill(billId, vendorCompany) {
  if (!confirm(`Are you sure you want to delete bill ${billId} from ${vendorCompany}?`)) return;
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/bills/${encodeURIComponent(billId)}`, {
      method: 'DELETE',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: vendorCompany })
    });
    if (response.ok) {
      alert('Bill deleted successfully.');
      renderAdminData();
    } else {
      const data = await response.json();
      alert(data.error || 'Failed to delete bill.');
    }
  } catch (err) {
    alert('Could not connect to backend server.');
  }
}

// Export Bills to CSV
function exportAdminBillsToCSV() {
  if (!window.allBills || window.allBills.length === 0) {
    alert("No data available to export.");
    return;
  }
  
  let filteredBills = window.allBills;
  const filterSelect = document.getElementById('monthFilter');
  if (filterSelect && filterSelect.value !== 'all') {
    filteredBills = window.allBills.filter(b => b.date && b.date.startsWith(filterSelect.value));
  }

  const headers = ["Vendor", "Billed Company", "Invoice No", "Date", "Amount", "Approval Status", "Payment Status", "Actual Paid"];
  
  const csvRows = [];
  csvRows.push(headers.join(","));

  filteredBills.forEach(bill => {
    let approvalStatus = bill.status === 'Rejected' ? 'Rejected' : (bill.status === 'Pending' ? 'Pending' : 'Approved');
    let actualPaid = 0;
    if (bill.payments) {
      actualPaid = bill.payments.reduce((sum, p) => sum + p.amount, 0);
    }
    let paymentStatus = bill.status === 'Paid' ? 'Paid' : (actualPaid > 0 ? 'Partially Paid' : 'Unpaid');

    const row = [
      `"${bill.vendorCompany || ''}"`,
      `"${bill.billed_company || ''}"`,
      `"${bill.id || ''}"`,
      `"${bill.date || ''}"`,
      `"${bill.amount || 0}"`,
      `"${approvalStatus}"`,
      `"${paymentStatus}"`,
      `"${actualPaid}"`
    ];
    csvRows.push(row.join(","));
  });

  const csvContent = csvRows.join("\n");
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `vendor_bills_export_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Fetch and Render Bills Data
async function renderAdminData() {
  const tableBody = document.getElementById('adminTableBody');
  const statsGrid = document.getElementById('adminStatsGrid');
  
  if (tableBody) tableBody.innerHTML = '<tr><td colspan="6">Loading bills from database...</td></tr>';
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/bills`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    window.allBills = await response.json();
    const bills = window.allBills;
    let filteredBills = window.allBills;
    const filterSelect = document.getElementById('monthFilter');
    
    if (filterSelect && filterSelect.options.length <= 1) {
      const months = new Set();
      window.allBills.forEach(b => {
        if (b.date) months.add(b.date.substring(0, 7));
      });
      let optionsHtml = '<option value="all">All Time</option>';
      Array.from(months).sort().reverse().forEach(m => {
        optionsHtml += `<option value="${escapeHTML(m)}">${escapeHTML(m)}</option>`;
      });
      filterSelect.innerHTML = optionsHtml;
    }
    
    if (filterSelect && filterSelect.value !== 'all') {
      filteredBills = window.allBills.filter(b => b.date && b.date.startsWith(filterSelect.value));
    }
    
    let totalPending = 0;
    let totalApproved = 0;
    let totalPaid = 0;

    filteredBills.forEach(b => {
      let actualPaid = 0;
      if (b.payments && b.payments.length > 0) {
        actualPaid = b.payments.reduce((sum, p) => sum + p.amount, 0);
      }
      totalPaid += actualPaid;

      if (b.status === 'Pending') {
        totalPending += b.amount;
      } else if (b.status === 'Approved' || b.status === 'Partially Paid') {
        totalApproved += (b.amount - actualPaid);
      }
    });

    if (statsGrid) {
      statsGrid.innerHTML = `
        <div class="stat-card">
          <h3>Total Pending</h3>
          <div class="value">${formatCurrency(totalPending)}</div>
        </div>
        <div class="stat-card">
          <h3>Total Approved (Unpaid)</h3>
          <div class="value" style="color:var(--secondary)">${formatCurrency(totalApproved)}</div>
        </div>
        <div class="stat-card">
          <h3>Total Paid</h3>
          <div class="value" style="color:var(--accent)">${formatCurrency(totalPaid)}</div>
        </div>
      `;
    }

    if (tableBody) tableBody.innerHTML = '';
    
    if (filteredBills.length === 0 && tableBody) {
      tableBody.innerHTML = '<tr><td colspan="7">No bills submitted for this period.</td></tr>';
      return;
    }

    filteredBills.forEach(bill => {
      const tr = document.createElement('tr');
      
      let approvalStatus = bill.status === 'Rejected' ? 'Rejected' : (bill.status === 'Pending' ? 'Pending' : 'Approved');
      
      const statusSelect = `
        <select class="status-select" onchange="updateBillStatus('${escapeHTML(bill.id)}', '${escapeHTML(bill.vendorCompany)}', this.value)" style="padding:4px; border-radius:4px; border:1px solid var(--border); font-size:0.85rem;">
          <option value="Pending" ${approvalStatus === 'Pending' ? 'selected' : ''}>Pending</option>
          <option value="Approved" ${approvalStatus === 'Approved' ? 'selected' : ''}>Approved</option>
          <option value="Rejected" ${approvalStatus === 'Rejected' ? 'selected' : ''}>Rejected</option>
        </select>
      `;

      let paymentBtnHtml = '';
      if (approvalStatus === 'Approved') {
        paymentBtnHtml = `<button class="action-btn" style="background:var(--secondary); padding:4px 8px; font-size:0.85rem;" onclick="openPaymentModal('${escapeHTML(bill.id)}', '${escapeHTML(bill.vendorCompany)}')">Payments (${bill.payments ? bill.payments.length : 0})</button>`;
      }

      const actions = `
        <div class="action-btns" style="display:flex; gap:8px;">
          ${paymentBtnHtml}
          <button class="action-btn btn-reject" style="padding:4px 8px; font-size:0.85rem;" onclick="deleteBill('${escapeHTML(bill.id)}', '${escapeHTML(bill.vendorCompany)}')">Delete</button>
        </div>
      `;

      const downloadLink = bill.file_path ? `<a href="#" onclick="downloadSecureFile('${bill.file_path}', ''); return false;" style="color:var(--secondary); font-size:0.85rem; text-decoration:none; font-weight:500;">Download</a>` : '<span style="color:#aaa; font-size:0.85rem">No file</span>';
      
      let actualPaid = 0;
      if (bill.payments) {
          actualPaid = bill.payments.reduce((sum, p) => sum + p.amount, 0);
      }
      let paymentStatusStr = bill.status === 'Paid' ? 'Paid' : (actualPaid > 0 ? `Partially Paid (${formatCurrency(actualPaid)})` : 'Unpaid');

      tr.innerHTML = `
        <td>
          <strong>${escapeHTML(bill.vendorCompany)}</strong>
          <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Billed to: ${escapeHTML(bill.billed_company || 'N/A')}</div>
        </td>
        <td>${escapeHTML(bill.id)}</td>
        <td>${escapeHTML(bill.date)}</td>
        <td>${formatCurrency(bill.amount)}</td>
        <td>
          <div style="margin-bottom:4px;">${statusSelect}</div>
          <span style="font-size:0.75rem; color:var(--text-muted);">${paymentStatusStr}</span>
        </td>
        <td>${downloadLink}</td>
        <td>${actions}</td>
      `;
      if (tableBody) tableBody.appendChild(tr);
    });

  } catch (err) {
    if (tableBody) tableBody.innerHTML = '<tr><td colspan="6" style="color:var(--danger)">Failed to connect to database. Make sure CG_Server.py is running.</td></tr>';
  }
}

// Render Vendors list
async function renderVendors() {
  const vBody = document.getElementById('adminVendorsBody');
  if (!vBody) return;

  vBody.innerHTML = '<tr><td colspan="4">Loading vendors...</td></tr>';
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/vendors`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const vendors = await response.json();

    vBody.innerHTML = '';
    if (vendors.length === 0) {
      vBody.innerHTML = '<tr><td colspan="4">No vendors registered.</td></tr>';
      return;
    }

    vendors.forEach(v => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${escapeHTML(v.company)}</strong></td>
        <td>${escapeHTML(v.name)}<br><span style="font-size:0.8rem;color:var(--text-muted)">${escapeHTML(v.designation)}</span></td>
        <td>${escapeHTML(v.email)}<br><span style="font-size:0.8rem;color:var(--text-muted)">${escapeHTML(v.contact)}</span></td>
        <td>
          <div style="display: flex; gap: 8px;">
            <button class="action-btn" style="background:var(--secondary);" onclick="changeVendorPassword('${escapeHTML(v.company)}')">Change Password</button>
            <button class="action-btn" style="background:var(--danger);" onclick="deleteVendorAccount('${escapeHTML(v.company)}')">Delete</button>
          </div>
        </td>
      `;
      vBody.appendChild(tr);
    });
  } catch (err) {
    vBody.innerHTML = '<tr><td colspan="4" style="color:var(--danger)">Failed to connect to backend server.</td></tr>';
  }
}

// Delete Vendor Account
async function deleteVendorAccount(company) {
  if (!confirm(`WARNING: Are you absolutely sure you want to delete the vendor "${company}"?\n\nThis action will:\n1. Delete their account and prevent login.\n2. Archive all their uploaded bills into a ZIP file.\n3. Delete their specific database.\n\nThis cannot be undone.`)) {
    return;
  }
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/vendors/${encodeURIComponent(company)}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (response.ok) {
      alert(`Vendor "${company}" and their data have been successfully deleted and archived.`);
      renderVendors();
      // Optional: render admin data if it displays bills
      if (document.getElementById('page-all-bills').classList.contains('active')) {
        renderAdminData();
      }
    } else {
      const data = await response.json();
      alert(data.error || 'Failed to delete vendor.');
    }
  } catch (err) {
    alert('Could not connect to backend server.');
  }
}

// Admin Create Vendor
async function handleAdminCreateVendor(e) {
  e.preventDefault();
  const btn = document.getElementById('adminCreateVendorBtn');
  btn.textContent = 'Creating...';

  const payload = {
    company: document.getElementById('adminNewVendorCompany').value,
    name: document.getElementById('adminNewVendorName').value,
    designation: document.getElementById('adminNewVendorDesignation').value,
    email: document.getElementById('adminNewVendorEmail').value,
    contact: document.getElementById('adminNewVendorContact').value,
    gst: document.getElementById('adminNewVendorGst').value.toUpperCase(),
    address: document.getElementById('adminNewVendorAddress').value,
    password: document.getElementById('adminNewVendorPassword').value
  };

  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/create-vendor`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    
    const result = await response.json();
    btn.textContent = 'Create Vendor';
    
    if (response.ok) {
      alert('Vendor created successfully!');
      document.getElementById('adminCreateVendorForm').style.display = 'none';
      e.target.reset();
      document.getElementById('adminCreateVendorError').style.display = 'none';
      renderVendors();
    } else {
      document.getElementById('adminCreateVendorError').textContent = result.error || 'Failed to create vendor.';
      document.getElementById('adminCreateVendorError').style.display = 'block';
    }
  } catch(err) {
    btn.textContent = 'Create Vendor';
    document.getElementById('adminCreateVendorError').textContent = 'Could not connect to server.';
    document.getElementById('adminCreateVendorError').style.display = 'block';
  }
}

// Render Activity Logs
async function renderActivityLogs() {
  const aBody = document.getElementById('adminActivityBody');
  const vBody = document.getElementById('vendorActivityBody');
  if (!aBody || !vBody) return;

  aBody.innerHTML = '<tr><td colspan="2">Loading logs...</td></tr>';
  vBody.innerHTML = '<tr><td colspan="3">Loading logs...</td></tr>';
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/logs`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const logs = await response.json();

    aBody.innerHTML = '';
    if (logs.length === 0) {
      aBody.innerHTML = '<tr><td colspan="2">No activity logged.</td></tr>';
    } else {
      logs.forEach(log => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="white-space:nowrap; color:var(--text-muted)">${escapeHTML(log.timestamp)}</td>
          <td>${log.action}</td>
        `;
        aBody.appendChild(tr);
      });
    }

    const vResponse = await fetch(`${API_BASE}/admin/vendor-logs`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const vLogs = await vResponse.json();

    vBody.innerHTML = '';
    if (vLogs.length === 0) {
      vBody.innerHTML = '<tr><td colspan="3">No vendor activity logged.</td></tr>';
    } else {
      vLogs.forEach(log => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="white-space:nowrap; color:var(--text-muted)">${escapeHTML(log.timestamp)}</td>
          <td><strong>${log.company}</strong></td>
          <td>${log.action}</td>
        `;
        vBody.appendChild(tr);
      });
    }

  } catch (err) {
    aBody.innerHTML = '<tr><td colspan="2" style="color:var(--danger)">Failed to fetch logs.</td></tr>';
    vBody.innerHTML = '<tr><td colspan="3" style="color:var(--danger)">Failed to fetch vendor logs.</td></tr>';
  }
}

// Admin change vendor password
async function changeVendorPassword(company) {
  const newPass = prompt(`Enter new password for ${company}:`);
  if (!newPass) return;
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/change-vendor-password`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ company: company, new_password: newPass })
    });
    
    if (response.ok) {
      alert(`Password for ${company} updated successfully.`);
    } else {
      alert('Failed to update password.');
    }
  } catch (err) {
    alert('Failed to connect to server.');
  }
}

// Admin Update Credentials
async function handleAdminCredentialsUpdate(e) {
  e.preventDefault();
  const newUser = document.getElementById('adminNewUser').value;
  const newPass = document.getElementById('adminNewPass').value;
  const btn = document.getElementById('adminCredBtn');
  
  btn.textContent = 'Updating...';
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/update-credentials`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ old_username: currentAdminUser, new_username: newUser, new_password: newPass })
    });
    
    btn.textContent = 'Update Credentials';
    if (response.ok) {
      document.getElementById('adminCredSuccess').style.display = 'block';
      document.getElementById('adminCredError').style.display = 'none';
      
      // Update local storage and UI
      localStorage.setItem('adminUser', newUser);
      document.getElementById('adminHeaderName').textContent = newUser;
      
      setTimeout(() => { document.getElementById('adminCredSuccess').style.display = 'none'; }, 3000);
    } else {
      document.getElementById('adminCredError').style.display = 'block';
      document.getElementById('adminCredSuccess').style.display = 'none';
    }
  } catch (err) {
    btn.textContent = 'Update Credentials';
    document.getElementById('adminCredError').textContent = 'Could not connect to server.';
    document.getElementById('adminCredError').style.display = 'block';
  }
}

// Manage Accounts Users
async function renderAccountsUsers() {
  const tbody = document.getElementById('adminAccountsUsersBody');
  if (!tbody) return;
  
  tbody.innerHTML = '<tr><td colspan="2">Loading...</td></tr>';
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/accounts-users`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const users = await response.json();
    
    tbody.innerHTML = '';
    if (users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="2">No accounts users found.</td></tr>';
    } else {
      users.forEach(u => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${escapeHTML(u.username)}</td>
          <td>
            <button onclick="deleteAccountsUser('${escapeHTML(u.username)}')" style="background:var(--danger); padding:4px 8px; border:none; border-radius:4px; color:white; cursor:pointer; font-size:0.8rem;">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    }
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="2" style="color:var(--danger)">Failed to load accounts users.</td></tr>';
  }
}

async function handleCreateAccountsUser(e) {
  e.preventDefault();
  const newUser = document.getElementById('newAccUser').value;
  const newPass = document.getElementById('newAccPass').value;
  
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/accounts-users`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ username: newUser, password: newPass })
    });
    
    if (response.ok) {
      document.getElementById('adminAccUserSuccess').style.display = 'block';
      document.getElementById('adminAccUserError').style.display = 'none';
      document.getElementById('newAccUser').value = '';
      document.getElementById('newAccPass').value = '';
      renderAccountsUsers();
      setTimeout(() => { document.getElementById('adminAccUserSuccess').style.display = 'none'; }, 3000);
    } else {
      const data = await response.json();
      document.getElementById('adminAccUserError').textContent = data.error || 'Failed to create user.';
      document.getElementById('adminAccUserError').style.display = 'block';
      document.getElementById('adminAccUserSuccess').style.display = 'none';
    }
  } catch (err) {
    document.getElementById('adminAccUserError').textContent = 'Could not connect to server.';
    document.getElementById('adminAccUserError').style.display = 'block';
  }
}

async function deleteAccountsUser(username) {
  if (!confirm(`Are you sure you want to delete Accounts User: ${username}?`)) return;
  try {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE}/admin/accounts-users/${encodeURIComponent(username)}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (response.ok) {
      renderAccountsUsers();
    } else {
      alert('Failed to delete user.');
    }
  } catch (err) {
    alert('Connection error');
  }
}

// Initial render
document.addEventListener('DOMContentLoaded', () => {
  const headerName = document.getElementById('adminHeaderName');
  if (headerName && currentAdminUser) {
    headerName.textContent = currentAdminUser;
  }
  
  // Set default values in settings
  const adminNewUser = document.getElementById('adminNewUser');
  if (adminNewUser) {
    adminNewUser.value = currentAdminUser;
  }

  renderAdminData();
});



// Secure Download
async function downloadSecureFile(filepath, company = '') {
  let tokenName = 'vendorToken';
  if (window.location.pathname.includes('admin')) tokenName = 'adminToken';
  if (window.location.pathname.includes('accounts')) tokenName = 'accountsToken';
  
  const token = localStorage.getItem(tokenName);
  
  try {
    const response = await fetch(`${API_BASE}/download?file=${filepath}&vendorCompany=${encodeURIComponent(company)}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filepath.split('/').pop();
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } else {
      alert('Failed to download file. You may not have permission.');
    }
  } catch (err) {
    alert('Network error while downloading.');
  }
}
