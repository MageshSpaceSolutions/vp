// Global Configuration
// Automatically detects local development vs production (Nginx) environments
let API_BASE = '/api';

if (window.location.protocol === 'file:' || 
    ((window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') && 
     window.location.port !== '80' && window.location.port !== '')) {
    // Local development fallback
    API_BASE = 'http://localhost:1512/api';
}
