import sqlite3
import json
import random
import os
import time
import hashlib
import hmac
import base64
import gzip
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.parse
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)

# Load or generate SECRET_KEY for JWT
SECRET_KEY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'secret.key')
if os.path.exists(SECRET_KEY_FILE):
    with open(SECRET_KEY_FILE, 'rb') as f:
        SECRET_KEY = f.read()
else:
    SECRET_KEY = os.urandom(32)
    with open(SECRET_KEY_FILE, 'wb') as f:
        f.write(SECRET_KEY)

# JWT Helpers
def create_token(user_id, role):
    header = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').decode().rstrip("=")
    payload = base64.urlsafe_b64encode(json.dumps({"sub": user_id, "role": role, "exp": int(time.time()) + 86400}).encode()).decode().rstrip("=")
    signature = base64.urlsafe_b64encode(hmac.new(SECRET_KEY, f"{header}.{payload}".encode(), hashlib.sha256).digest()).decode().rstrip("=")
    return f"{header}.{payload}.{signature}"

def verify_token(token, expected_role=None):
    try:
        header, payload, signature = token.split('.')
        expected_sig = base64.urlsafe_b64encode(hmac.new(SECRET_KEY, f"{header}.{payload}".encode(), hashlib.sha256).digest()).decode().rstrip("=")
        if not hmac.compare_digest(signature, expected_sig):
            return None
        
        # Add padding back for b64decode
        payload_padded = payload + "=" * ((4 - len(payload) % 4) % 4)
        payload_data = json.loads(base64.urlsafe_b64decode(payload_padded).decode())
        
        if payload_data['exp'] < time.time():
            return None
        if expected_role and payload_data['role'] != expected_role:
            return None
        return payload_data
    except Exception:
        return None

# Password Hashing Helpers
def hash_password(password):
    salt = os.urandom(16)
    hash_val = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    return f"hash:{salt.hex()}:{hash_val.hex()}"

def verify_password(stored_password, provided_password):
    if stored_password.startswith('hash:'):
        _, salt_hex, hash_hex = stored_password.split(':')
        expected_hash = hashlib.pbkdf2_hmac('sha256', provided_password.encode(), bytes.fromhex(salt_hex), 100000).hex()
        return hmac.compare_digest(expected_hash, hash_hex)
        return hmac.compare_digest(expected_hash, hash_hex)
    else:
        return stored_password == provided_password

# Email Notification Helper
def send_email_notification(to_email, subject, body):
    try:
        config_path = os.path.join(BASE_DIR, 'config.json')
        if not os.path.exists(config_path):
            print("config.json not found. Email not sent.")
            return False
            
        with open(config_path, 'r') as f:
            config = json.load(f)
            
        smtp_user = config.get('smtp_user')
        smtp_password = config.get('smtp_password')
        
        if not smtp_user or not smtp_password or smtp_password == "YOUR_APP_PASSWORD_HERE":
            print("SMTP credentials not configured. Email not sent.")
            return False

        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))

        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            
        print(f"Email sent successfully to {to_email}")
        return True
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
        return False


VENDORS_DB = os.path.join(BASE_DIR, 'vendors.db')
ADMIN_DB = os.path.join(BASE_DIR, 'admin.db')
ACCOUNTS_DB = os.path.join(BASE_DIR, 'accounts.db')
VENDOR_DATA_DIR = os.path.join(PROJECT_ROOT, 'Vendor Data')

otp_store = {}

def get_vendor_db_path(company_name):
    safe_name = "".join([c for c in company_name if c.isalpha() or c.isdigit()]).rstrip()
    return os.path.join(VENDOR_DATA_DIR, f"{safe_name}_bills.db")

def get_db_connection(db_path):
    """Returns a highly concurrent SQLite connection optimized for multiple threads"""
    conn = sqlite3.connect(db_path, timeout=20.0)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA cache_size=10000')   # ~10 MB page cache in memory
    conn.execute('PRAGMA temp_store=MEMORY')  # Use RAM for temp tables
    conn.execute('PRAGMA mmap_size=268435456') # 256 MB memory-mapped I/O
    conn.execute('PRAGMA busy_timeout=20000')
    return conn

def init_db():
    if not os.path.exists(VENDOR_DATA_DIR):
        os.makedirs(VENDOR_DATA_DIR)

    # Vendors Database
    v_conn = get_db_connection(VENDORS_DB)
    v_c = v_conn.cursor()
    v_c.execute('''
        CREATE TABLE IF NOT EXISTS vendors (
            company TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            designation TEXT NOT NULL,
            email TEXT NOT NULL,
            gst TEXT NOT NULL,
            contact TEXT NOT NULL,
            address TEXT NOT NULL
        )
    ''')
    v_c.execute('''
        CREATE TABLE IF NOT EXISTS vendor_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            company TEXT NOT NULL,
            action TEXT NOT NULL
        )
    ''')
    v_c.execute('CREATE INDEX IF NOT EXISTS idx_vendor_logs_company ON vendor_logs(company)')
    v_c.execute('CREATE INDEX IF NOT EXISTS idx_vendor_logs_timestamp ON vendor_logs(timestamp)')
    v_conn.commit()
    v_conn.close()

    # Admin Database
    a_conn = get_db_connection(ADMIN_DB)
    a_c = a_conn.cursor()
    a_c.execute('''
        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    a_c.execute('''
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            action TEXT NOT NULL
        )
    ''')
    a_c.execute("SELECT COUNT(*) FROM admin_users")
    if a_c.fetchone()[0] == 0:
        a_c.execute("INSERT INTO admin_users (username, password) VALUES (?, ?)", ('admin', 'admin'))
    a_conn.commit()
    a_conn.close()

    # Accounts Database
    acc_conn = get_db_connection(ACCOUNTS_DB)
    acc_c = acc_conn.cursor()
    acc_c.execute('''
        CREATE TABLE IF NOT EXISTS accounts_users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    acc_c.execute("SELECT COUNT(*) FROM accounts_users")
    if acc_c.fetchone()[0] == 0:
        acc_c.execute("INSERT INTO accounts_users (username, password) VALUES (?, ?)", ('accounts', 'accounts'))
    acc_conn.commit()
    acc_conn.close()

def log_admin_activity(action):
    conn = get_db_connection(ADMIN_DB)
    c = conn.cursor()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute("INSERT INTO activity_logs (timestamp, action) VALUES (?, ?)", (timestamp, action))
    conn.commit()
    conn.close()

def log_vendor_activity(company, action):
    conn = get_db_connection(VENDORS_DB)
    c = conn.cursor()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute("INSERT INTO vendor_logs (timestamp, company, action) VALUES (?, ?, ?)", (timestamp, company, action))
    conn.commit()
    conn.close()

def get_vendor_email(company_name):
    conn = get_db_connection(VENDORS_DB)
    c = conn.cursor()
    c.execute("SELECT email FROM vendors WHERE company=?", (company_name,))
    row = c.fetchone()
    conn.close()
    return row[0] if row else None

def init_vendor_bill_db(db_path):
    conn = get_db_connection(db_path)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS bills (
            id TEXT PRIMARY KEY,
            vendorCompany TEXT NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            status TEXT NOT NULL
        )
    ''')
    try:
        c.execute("ALTER TABLE bills ADD COLUMN file_path TEXT")
    except sqlite3.OperationalError:
        pass
        
    try:
        c.execute("ALTER TABLE bills ADD COLUMN billed_company TEXT")
    except sqlite3.OperationalError:
        pass
        
    c.execute('''CREATE TABLE IF NOT EXISTS payments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id TEXT, date TEXT, amount REAL, reference TEXT)''')
                 
    c.execute('''CREATE TABLE IF NOT EXISTS bank_accounts
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  bank_name TEXT,
                  account_number TEXT,
                  ifsc_code TEXT,
                  cheque_file_path TEXT,
                  status TEXT)''')
                  
    c.execute('CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_bills_date ON bills(date)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_bills_vendor ON bills(vendorCompany)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_payments_bill_id ON payments(bill_id)')
                 
    conn.commit()
    conn.close()

class SimpleAPIHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status_code=200):
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        # Security Headers
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        self.end_headers()

    def _send_json(self, data, status_code=200):
        """Sends a gzip-compressed JSON response for faster transmission."""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        # Check if client accepts gzip
        accept_encoding = self.headers.get('Accept-Encoding', '')
        payload = json.dumps(data).encode('utf-8')
        if 'gzip' in accept_encoding:
            payload = gzip.compress(payload)
            self.send_header('Content-Encoding', 'gzip')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self):
        self._set_headers()

    def _verify_auth(self):
        auth_header = self.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return None
        token = auth_header.split(' ')[1]
        payload = verify_token(token)
        return payload

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed_path.query)

        payload = self._verify_auth()
        if not payload:
            self._set_headers(401)
            self.wfile.write(json.dumps({'error': 'Unauthorized'}).encode('utf-8'))
            return
        
        if parsed_path.path == '/api/bills':
            vendor_company = query.get('vendorCompany', [None])[0]
            
            # Role check & IDOR prevention
            if payload['role'] == 'vendor':
                if not vendor_company or vendor_company.lower() != payload['sub'].lower():
                    self._set_headers(403)
                    self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                    return
            elif payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            bills = []
            if vendor_company:
                db_path = get_vendor_db_path(vendor_company)
                if os.path.exists(db_path):
                    conn = get_db_connection(db_path)
                    conn.row_factory = sqlite3.Row
                    c = conn.cursor()
                    c.execute("SELECT * FROM bills ORDER BY date DESC")
                    bills = [dict(row) for row in c.fetchall()]
                    
                    for b in bills:
                        c.execute("SELECT * FROM payments WHERE bill_id=?", (b['id'],))
                        b['payments'] = [dict(row) for row in c.fetchall()]
                    conn.close()
            else:
                for filename in os.listdir(VENDOR_DATA_DIR):
                    if filename.endswith(".db"):
                        db_path = os.path.join(VENDOR_DATA_DIR, filename)
                        conn = get_db_connection(db_path)
                        conn.row_factory = sqlite3.Row
                        c = conn.cursor()
                        try:
                            c.execute("SELECT * FROM bills")
                            vendor_bills = [dict(row) for row in c.fetchall()]
                            
                            for b in vendor_bills:
                                try:
                                    c.execute("SELECT * FROM payments WHERE bill_id=?", (b['id'],))
                                    b['payments'] = [dict(row) for row in c.fetchall()]
                                except sqlite3.OperationalError:
                                    b['payments'] = []
                                    
                            bills.extend(vendor_bills)
                        except sqlite3.OperationalError:
                            pass
                        conn.close()
                bills.sort(key=lambda x: x['date'], reverse=True)
                
            self._send_json(bills)
            
        elif parsed_path.path == '/api/vendors':
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT company, name, designation, email, gst, contact, address FROM vendors")
            vendors = [dict(row) for row in c.fetchall()]
            conn.close()
            self._set_headers()
            self.wfile.write(json.dumps(vendors).encode('utf-8'))

        elif parsed_path.path == '/api/admin/logs':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(ADMIN_DB)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM activity_logs ORDER BY id DESC")
            logs = [dict(row) for row in c.fetchall()]
            conn.close()
            self._set_headers()
            self.wfile.write(json.dumps(logs).encode('utf-8'))
            
        elif parsed_path.path == '/api/admin/vendor-logs':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM vendor_logs ORDER BY id DESC")
            logs = [dict(row) for row in c.fetchall()]
            conn.close()
            self._set_headers()
            self.wfile.write(json.dumps(logs).encode('utf-8'))

        elif parsed_path.path == '/api/admin/accounts-users':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(ACCOUNTS_DB)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT id, username FROM accounts_users")
            acc_users = [dict(row) for row in c.fetchall()]
            conn.close()
            self._set_headers()
            self.wfile.write(json.dumps(acc_users).encode('utf-8'))

        elif parsed_path.path == '/api/download':
            file_param = query.get('file', [None])[0]
            if file_param:
                if payload['role'] == 'vendor':
                    safe_name = "".join([c for c in payload['sub'] if c.isalpha() or c.isdigit()])
                    if not (file_param.startswith(safe_name) or file_param.startswith(f"banks/{safe_name}")):
                        self._set_headers(403)
                        self.wfile.write(json.dumps({'error': 'Forbidden: Identity mismatch'}).encode('utf-8'))
                        return
                full_path = os.path.abspath(os.path.join(VENDOR_DATA_DIR, file_param))
                expected_dir = os.path.abspath(VENDOR_DATA_DIR)
                
                # Prevent Path Traversal
                if full_path.startswith(expected_dir) and os.path.isfile(full_path):
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/octet-stream')
                    self.send_header('Content-Disposition', f'attachment; filename="{os.path.basename(file_param)}"')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    with open(full_path, 'rb') as f:
                        self.wfile.write(f.read())
                    return
            self._set_headers(404)
            self.wfile.write(json.dumps({'error': 'File not found or access denied'}).encode('utf-8'))

        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'error': 'Not found'}).encode('utf-8'))

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b'{}'
        data = json.loads(post_data.decode('utf-8'))
        
        public_endpoints = ['/api/signup', '/api/login', '/api/admin-login', '/api/accounts-login', '/api/forgot-password/send-otp', '/api/forgot-password/reset']
        if self.path not in public_endpoints:
            payload = self._verify_auth()
            if not payload:
                self._set_headers(401)
                self.wfile.write(json.dumps({'error': 'Unauthorized'}).encode('utf-8'))
                return
        
        if self.path == '/api/signup':
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            try:
                hashed_pw = hash_password(data['password'])
                c.execute('''INSERT INTO vendors 
                             (company, password, name, designation, email, gst, contact, address) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                          (data['company'], hashed_pw, data['name'], data['designation'], 
                           data['email'], data['gst'], data['contact'], data['address']))
                conn.commit()
                init_vendor_bill_db(get_vendor_db_path(data['company']))
                log_vendor_activity(data['company'], "Vendor registered account")
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'Company registered'}).encode('utf-8'))
            except sqlite3.IntegrityError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Company Name already exists'}).encode('utf-8'))
            conn.close()

        elif self.path == '/api/admin/create-vendor':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            try:
                hashed_pw = hash_password(data['password'])
                c.execute('''INSERT INTO vendors 
                             (company, password, name, designation, email, gst, contact, address) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                          (data['company'], hashed_pw, data['name'], data['designation'], 
                           data['email'], data['gst'], data['contact'], data['address']))
                conn.commit()
                init_vendor_bill_db(get_vendor_db_path(data['company']))
                log_admin_activity(f"Admin created a new vendor: {data['company']}")
                log_vendor_activity(data['company'], "Account created by Admin")
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'Vendor created by admin'}).encode('utf-8'))
            except sqlite3.IntegrityError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Company Name already exists'}).encode('utf-8'))
            conn.close()
            
        elif self.path == '/api/accounts/create-vendor':
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            try:
                hashed_pw = hash_password(data['password'])
                c.execute('''INSERT INTO vendors 
                             (company, password, name, designation, email, gst, contact, address) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                          (data['company'], hashed_pw, data['name'], data['designation'], 
                           data['email'], data['gst'], data['contact'], data['address']))
                conn.commit()
                init_vendor_bill_db(get_vendor_db_path(data['company']))
                log_vendor_activity(data['company'], "Account created by Accounts Dept")
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'Vendor created by accounts'}).encode('utf-8'))
            except sqlite3.IntegrityError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Company Name already exists'}).encode('utf-8'))
            conn.close()

        elif self.path == '/api/login':
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            c.execute("SELECT company, password FROM vendors WHERE LOWER(company)=LOWER(?)", (data['company'],))
            row = c.fetchone()
            conn.close()
            if row and verify_password(row[1], data['password']):
                token = create_token(row[0], 'vendor')
                log_vendor_activity(row[0], "Logged in to Vendor Portal")
                self._set_headers(200)
                self.wfile.write(json.dumps({'company': row[0], 'token': token}).encode('utf-8'))
            else:
                time.sleep(random.uniform(1.0, 2.5)) # Brute force mitigation
                self._set_headers(401)
                self.wfile.write(json.dumps({'error': 'Invalid credentials'}).encode('utf-8'))
                
        elif self.path == '/api/admin-login':
            conn = get_db_connection(ADMIN_DB)
            c = conn.cursor()
            c.execute("SELECT username, password FROM admin_users WHERE LOWER(username)=LOWER(?)", (data['username'],))
            row = c.fetchone()
            conn.close()
            if row and verify_password(row[1], data['password']):
                token = create_token(row[0], 'admin')
                log_admin_activity(f"Admin logged in: {row[0]}")
                self._set_headers(200)
                self.wfile.write(json.dumps({'username': row[0], 'token': token}).encode('utf-8'))
            else:
                time.sleep(random.uniform(1.0, 2.5)) # Brute force mitigation
                self._set_headers(401)
                self.wfile.write(json.dumps({'error': 'Invalid admin credentials'}).encode('utf-8'))

        elif self.path == '/api/accounts-login':
            conn = get_db_connection(ACCOUNTS_DB)
            c = conn.cursor()
            c.execute("SELECT username, password FROM accounts_users WHERE LOWER(username)=LOWER(?)", (data['username'],))
            row = c.fetchone()
            conn.close()
            if row and verify_password(row[1], data['password']):
                token = create_token(row[0], 'accounts')
                self._set_headers(200)
                self.wfile.write(json.dumps({'username': row[0], 'token': token}).encode('utf-8'))
            else:
                time.sleep(random.uniform(1.0, 2.5)) # Brute force mitigation
                self._set_headers(401)
                self.wfile.write(json.dumps({'error': 'Invalid accounts credentials'}).encode('utf-8'))

        elif self.path == '/api/bills':
            # Role check & IDOR prevention
            if payload['role'] == 'vendor' and data['vendorCompany'].lower() != payload['sub'].lower():
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden: Identity mismatch'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(data['vendorCompany'])
            init_vendor_bill_db(db_path)
            
            # Save file if provided
            file_path = ""
            if 'fileData' in data and data['fileData']:
                bills_dir = os.path.join(VENDOR_DATA_DIR, 'bills')
                if not os.path.exists(bills_dir):
                    os.makedirs(bills_dir)
                safe_comp = "".join([c for c in data['vendorCompany'] if c.isalpha() or c.isdigit()]).rstrip()
                safe_id = "".join([c for c in data['id'] if c.isalpha() or c.isdigit()]).rstrip()
                
                # Sanitize File Extension
                file_ext = data.get('fileName', 'doc.pdf').split('.')[-1].lower()
                valid_exts = {'pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'}
                if file_ext not in valid_exts:
                    file_ext = 'pdf' # Fallback safe extension
                    
                file_name = f"{safe_comp}_{safe_id}.{file_ext}"
                file_path = f"bills/{file_name}"
                full_path = os.path.join(VENDOR_DATA_DIR, file_path)
                
                # The fileData is a base64 Data URL: "data:application/pdf;base64,JVBERi0xLjQKJ..."
                import base64
                header, encoded = data['fileData'].split(",", 1) if "," in data['fileData'] else ("", data['fileData'])
                with open(full_path, "wb") as f:
                    f.write(base64.b64decode(encoded))
            
            conn = get_db_connection(db_path)
            c = conn.cursor()
            try:
                c.execute("INSERT INTO bills (id, vendorCompany, amount, date, status, file_path, billed_company) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (data['id'], data['vendorCompany'], data['amount'], data['date'], 'Pending', file_path, data.get('billedCompany', '')))
                conn.commit()
                log_vendor_activity(data['vendorCompany'], f"Submitted bill {data['id']} for {data['amount']}")
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'Bill added'}).encode('utf-8'))
            except sqlite3.IntegrityError:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Invoice ID already exists'}).encode('utf-8'))
            conn.close()

        elif self.path == '/api/forgot-password/send-otp':
            time.sleep(random.uniform(1.0, 2.0)) # Throttle to prevent spam
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            c.execute("SELECT email FROM vendors WHERE company=?", (data['company'],))
            row = c.fetchone()
            conn.close()
            if row:
                email = row[0]
                otp = str(random.randint(100000, 999999))
                otp_store[data['company']] = otp
                
                send_email_notification(
                    email,
                    "Chandra Group Vendor Portal - Password Reset OTP",
                    f"Your One Time Password (OTP) to reset your password is: <b style='font-size: 1.2em; color: #1e40af;'>{otp}</b><br><br>If you did not request a password reset, please ignore this email."
                )
                
                log_vendor_activity(data['company'], "Requested password reset OTP")
                self._set_headers(200)
                self.wfile.write(json.dumps({'message': 'OTP sent'}).encode('utf-8'))
            else:
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Company not found'}).encode('utf-8'))

        elif self.path == '/api/forgot-password/reset':
            company = data['company']
            otp = data['otp']
            new_password = data['new_password']
            if company in otp_store and otp_store[company] == otp:
                conn = get_db_connection(VENDORS_DB)
                c = conn.cursor()
                hashed_pw = hash_password(new_password)
                c.execute("UPDATE vendors SET password=? WHERE company=?", (hashed_pw, company))
                conn.commit()
                conn.close()
                del otp_store[company]
                log_vendor_activity(company, "Reset password using OTP")
                self._set_headers(200)
                self.wfile.write(json.dumps({'message': 'Password reset successfully'}).encode('utf-8'))
            else:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Invalid OTP'}).encode('utf-8'))
                
        elif parsed_path.path == '/api/admin/accounts-users':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(ACCOUNTS_DB)
            c = conn.cursor()
            c.execute("SELECT id, username FROM accounts_users")
            users = [{'id': row[0], 'username': row[1]} for row in c.fetchall()]
            conn.close()
            self._set_headers(200)
            self.wfile.write(json.dumps(users).encode('utf-8'))
            
        elif parsed_path.path == '/api/banks':
            vendor_company = query.get('vendorCompany', [None])[0]
            if not vendor_company:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return
                
            # Role check & IDOR prevention
            if payload['role'] == 'vendor' and vendor_company.lower() != payload['sub'].lower():
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden: Identity mismatch'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(vendor_company)
            if not os.path.exists(db_path):
                self._set_headers(200)
                self.wfile.write(json.dumps([]).encode('utf-8'))
                return
                
            try:
                conn = get_db_connection(db_path)
                c = conn.cursor()
                c.execute("SELECT id, bank_name, account_number, ifsc_code, cheque_file_path, status FROM bank_accounts")
                banks = [{'id': r[0], 'bank_name': r[1], 'account_number': r[2], 'ifsc_code': r[3], 'cheque_file_path': r[4], 'status': r[5]} for r in c.fetchall()]
                conn.close()
                self._set_headers(200)
                self.wfile.write(json.dumps(banks).encode('utf-8'))
            except sqlite3.OperationalError:
                self._set_headers(200)
                self.wfile.write(json.dumps([]).encode('utf-8'))
                
        
        elif self.path == '/api/banks':
            if payload['role'] == 'vendor' and data['vendorCompany'].lower() != payload['sub'].lower():
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden: Identity mismatch'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(data['vendorCompany'])
            if not os.path.exists(db_path):
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Vendor DB not found'}).encode('utf-8'))
                return
                
            import base64
            # Handle cheque file upload
            cheque_path = None
            if 'fileData' in data and 'fileName' in data:
                banks_dir = os.path.join(VENDOR_DATA_DIR, 'banks')
                os.makedirs(banks_dir, exist_ok=True)
                file_ext = os.path.splitext(data['fileName'])[1]
                safe_name = "".join([c for c in data['vendorCompany'] if c.isalpha() or c.isdigit()])
                timestamp = int(time.time())
                cheque_filename = f"{safe_name}_{timestamp}{file_ext}"
                cheque_path = os.path.join(banks_dir, cheque_filename)
                
                try:
                    file_data = data['fileData']
                    if ',' in file_data:
                        file_data = file_data.split(',')[1]
                    with open(cheque_path, 'wb') as f:
                        f.write(base64.b64decode(file_data))
                except Exception as e:
                    print(f"Error saving cheque: {e}")
                    self._set_headers(500)
                    self.wfile.write(json.dumps({'error': 'Failed to save cheque'}).encode('utf-8'))
                    return
            else:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Cancelled cheque file required'}).encode('utf-8'))
                return

            conn = get_db_connection(db_path)
            c = conn.cursor()
            c.execute("INSERT INTO bank_accounts (bank_name, account_number, ifsc_code, cheque_file_path, status) VALUES (?, ?, ?, ?, ?)",
                      (data['bank_name'], data['account_number'], data['ifsc_code'], cheque_filename, 'Pending'))
            conn.commit()
            conn.close()
            log_vendor_activity(data['vendorCompany'], "Added a new bank account")
            self._set_headers(201)
            self.wfile.write(json.dumps({'message': 'Bank account added successfully'}).encode('utf-8'))

        elif self.path == '/api/admin/accounts-users':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(ACCOUNTS_DB)
            c = conn.cursor()
            c.execute("SELECT id FROM accounts_users WHERE LOWER(username)=LOWER(?)", (data['username'],))
            if c.fetchone():
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Username already exists'}).encode('utf-8'))
            else:
                hashed_pw = hash_password(data['password'])
                c.execute("INSERT INTO accounts_users (username, password) VALUES (?, ?)", (data['username'], hashed_pw))
                conn.commit()
                log_admin_activity(f"Created new Accounts user: {data['username']}")
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'User created'}).encode('utf-8'))
            conn.close()

        else:
            parsed_path = urllib.parse.urlparse(self.path)
            if parsed_path.path.startswith('/api/bills/') and parsed_path.path.endswith('/payments'):
                if payload['role'] not in ['admin', 'accounts']:
                    self._set_headers(403)
                    self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                    return
                    
                path_parts = parsed_path.path.split('/')
                bill_id = urllib.parse.unquote(path_parts[-2])
                vendor_company = data.get('vendorCompany')
                if not vendor_company:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                    return
                    
                db_path = get_vendor_db_path(vendor_company)
                conn = get_db_connection(db_path)
                c = conn.cursor()
                c.execute("INSERT INTO payments (bill_id, date, amount, reference) VALUES (?, ?, ?, ?)",
                          (bill_id, data['date'], data['amount'], data.get('reference', '')))
                
                # Automatically update status
                c.execute("SELECT amount FROM bills WHERE id=?", (bill_id,))
                bill_row = c.fetchone()
                if bill_row:
                    bill_amount = bill_row[0]
                    c.execute("SELECT SUM(amount) FROM payments WHERE bill_id=?", (bill_id,))
                    total_payments = c.fetchone()[0] or 0.0
                    
                    new_status = None
                    if total_payments >= bill_amount:
                        new_status = 'Paid'
                    elif total_payments > 0:
                        new_status = 'Partially Paid'
                        
                    if new_status:
                        c.execute("UPDATE bills SET status=? WHERE id=?", (new_status, bill_id))
                        
                conn.commit()
                conn.close()
                log_admin_activity(f"Payment of {data['amount']} added to bill {bill_id} ({vendor_company})")
                
                vendor_email = get_vendor_email(vendor_company)
                if vendor_email:
                    send_email_notification(
                        vendor_email,
                        f"Payment Added to Bill: {bill_id}",
                        f"A payment of <b>Rs {data['amount']}</b> has been added to your invoice <b>{bill_id}</b>."
                    )
                
                self._set_headers(201)
                self.wfile.write(json.dumps({'message': 'Payment added successfully'}).encode('utf-8'))
            else:
                self._set_headers(404)

    def do_PUT(self):
        payload = self._verify_auth()
        if not payload:
            self._set_headers(401)
            self.wfile.write(json.dumps({'error': 'Unauthorized'}).encode('utf-8'))
            return
            
        content_length = int(self.headers['Content-Length'])
        put_data = self.rfile.read(content_length)
        data = json.loads(put_data.decode('utf-8'))
        parsed_path = urllib.parse.urlparse(self.path)
        
        if parsed_path.path.startswith('/api/bills/'):
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            bill_id = urllib.parse.unquote(parsed_path.path[len('/api/bills/'):])
            vendor_company = data.get('vendorCompany')
            if not vendor_company:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(vendor_company)
            conn = get_db_connection(db_path)
            c = conn.cursor()
            c.execute("UPDATE bills SET status=? WHERE id=?", (data['status'], bill_id))
            if c.rowcount == 0:
                print(f"Warning: No rows updated for bill_id: {bill_id}")
            conn.commit()
            conn.close()
            
            log_admin_activity(f"Changed status of bill {bill_id} ({vendor_company}) to {data['status']}")
            
            vendor_email = get_vendor_email(vendor_company)
            if vendor_email:
                send_email_notification(
                    vendor_email,
                    f"Bill Status Updated: {bill_id}",
                    f"Your invoice <b>{bill_id}</b> status has been updated to <b>{data['status']}</b>."
                )
            
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Status updated'}).encode('utf-8'))
            
        elif parsed_path.path.startswith('/api/payments/'):
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            payment_id = urllib.parse.unquote(parsed_path.path[len('/api/payments/'):])
            vendor_company = data.get('vendorCompany')
            if not vendor_company:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(vendor_company)
            conn = get_db_connection(db_path)
            c = conn.cursor()
            
            c.execute("UPDATE payments SET date=?, amount=?, reference=? WHERE id=?", 
                      (data['date'], data['amount'], data.get('reference', ''), payment_id))
            
            c.execute("SELECT bill_id FROM payments WHERE id=?", (payment_id,))
            payment_row = c.fetchone()
            
            if payment_row:
                bill_id = payment_row[0]
                c.execute("SELECT amount FROM bills WHERE id=?", (bill_id,))
                bill_row = c.fetchone()
                if bill_row:
                    bill_amount = bill_row[0]
                    c.execute("SELECT SUM(amount) FROM payments WHERE bill_id=?", (bill_id,))
                    total_payments = c.fetchone()[0] or 0.0
                    
                    new_status = 'Pending'
                    if total_payments >= bill_amount:
                        new_status = 'Paid'
                    elif total_payments > 0:
                        new_status = 'Partially Paid'
                        
                    c.execute("UPDATE bills SET status=? WHERE id=?", (new_status, bill_id))
            
            conn.commit()
            conn.close()
            log_admin_activity(f"Modified payment {payment_id} ({vendor_company})")
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Payment updated'}).encode('utf-8'))
            
        elif self.path == '/api/admin/change-vendor-password':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            hashed_pw = hash_password(data['new_password'])
            c.execute("UPDATE vendors SET password=? WHERE company=?", (hashed_pw, data['company']))
            conn.commit()
            conn.close()
            log_admin_activity(f"Changed password for vendor: {data['company']}")
            log_vendor_activity(data['company'], "Password overridden by Admin")
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Password changed'}).encode('utf-8'))

        
        elif self.path == '/api/admin/banks':
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            vendor_company = data.get('vendorCompany')
            bank_id = data.get('bank_id')
            new_status = data.get('status')
            
            db_path = get_vendor_db_path(vendor_company)
            conn = get_db_connection(db_path)
            c = conn.cursor()
            c.execute("UPDATE bank_accounts SET status=? WHERE id=?", (new_status, bank_id))
            conn.commit()
            conn.close()
            
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Bank status updated'}).encode('utf-8'))

        elif self.path == '/api/admin/update-credentials':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            old_user = data['old_username']
            new_user = data['new_username']
            new_pass = hash_password(data['new_password'])
            conn = get_db_connection(ADMIN_DB)
            c = conn.cursor()
            c.execute("UPDATE admin_users SET username=?, password=? WHERE username=?", (new_user, new_pass, old_user))
            conn.commit()
            conn.close()
            log_admin_activity(f"Admin credentials updated (Username changed from {old_user} to {new_user})")
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Credentials updated'}).encode('utf-8'))
            
        elif self.path == '/api/admin/change-accounts-password':
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            acc_user = data['accounts_username']
            new_pass = hash_password(data['new_password'])
            conn = get_db_connection(ACCOUNTS_DB)
            c = conn.cursor()
            c.execute("UPDATE accounts_users SET password=? WHERE username=?", (new_pass, acc_user))
            conn.commit()
            conn.close()
            log_admin_activity(f"Admin updated password for Accounts user: {acc_user}")
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Accounts credentials updated'}).encode('utf-8'))

        elif self.path == '/api/vendor/change-password':
            if payload['role'] != 'vendor' or data['company'].lower() != payload['sub'].lower():
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            conn = get_db_connection(VENDORS_DB)
            c = conn.cursor()
            c.execute("SELECT password FROM vendors WHERE company=?", (data['company'],))
            row = c.fetchone()
            if row and verify_password(row[0], data['old_password']):
                new_pass = hash_password(data['new_password'])
                c.execute("UPDATE vendors SET password=? WHERE company=?", (new_pass, data['company']))
                conn.commit()
                conn.close()
                log_vendor_activity(data['company'], "Changed own password")
                self._set_headers(200)
                self.wfile.write(json.dumps({'message': 'Updated'}).encode('utf-8'))
            else:
                conn.close()
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'Incorrect password'}).encode('utf-8'))
        else:
            self._set_headers(404)

    def do_DELETE(self):
        payload = self._verify_auth()
        if not payload:
            self._set_headers(401)
            self.wfile.write(json.dumps({'error': 'Unauthorized'}).encode('utf-8'))
            return
            
        parsed_path = urllib.parse.urlparse(self.path)
        
        if parsed_path.path.startswith('/api/bills/'):
            bill_id = urllib.parse.unquote(parsed_path.path[len('/api/bills/'):])
            
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                delete_data = self.rfile.read(content_length)
                data = json.loads(delete_data.decode('utf-8'))
                vendor_company = data.get('vendorCompany')
            else:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return

            if not vendor_company:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return
                
            if payload['role'] == 'vendor' and vendor_company.lower() != payload['sub'].lower():
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden: Identity mismatch'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(vendor_company)
            if not os.path.exists(db_path):
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Vendor db not found'}).encode('utf-8'))
                return
                
            conn = get_db_connection(db_path)
            c = conn.cursor()
            
            # Fetch file_path before deleting
            c.execute("SELECT file_path FROM bills WHERE id=?", (bill_id,))
            row = c.fetchone()
            
            if row:
                file_path = row[0]
                if file_path:
                    full_path = os.path.join(VENDOR_DATA_DIR, file_path)
                    if os.path.exists(full_path):
                        try:
                            os.remove(full_path)
                        except Exception as e:
                            print(f"Error deleting file: {e}")
                
                c.execute("DELETE FROM bills WHERE id=?", (bill_id,))
                conn.commit()
                conn.close()
                log_vendor_activity(vendor_company, f"Deleted bill {bill_id}")
                self._set_headers(200)
                self.wfile.write(json.dumps({'message': 'Bill deleted successfully'}).encode('utf-8'))
            else:
                conn.close()
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Bill not found'}).encode('utf-8'))
                
        elif parsed_path.path.startswith('/api/payments/'):
            if payload['role'] not in ['admin', 'accounts']:
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            payment_id = urllib.parse.unquote(parsed_path.path[len('/api/payments/'):])
            
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                delete_data = self.rfile.read(content_length)
                data = json.loads(delete_data.decode('utf-8'))
                vendor_company = data.get('vendorCompany')
            else:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return

            if not vendor_company:
                self._set_headers(400)
                self.wfile.write(json.dumps({'error': 'vendorCompany required'}).encode('utf-8'))
                return
                
            db_path = get_vendor_db_path(vendor_company)
            if not os.path.exists(db_path):
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Vendor db not found'}).encode('utf-8'))
                return
                
            conn = get_db_connection(db_path)
            c = conn.cursor()
            
            c.execute("SELECT bill_id FROM payments WHERE id=?", (payment_id,))
            payment_row = c.fetchone()
            
            if payment_row:
                bill_id = payment_row[0]
                c.execute("DELETE FROM payments WHERE id=?", (payment_id,))
                
                c.execute("SELECT amount FROM bills WHERE id=?", (bill_id,))
                bill_row = c.fetchone()
                if bill_row:
                    bill_amount = bill_row[0]
                    c.execute("SELECT SUM(amount) FROM payments WHERE bill_id=?", (bill_id,))
                    total_payments = c.fetchone()[0] or 0.0
                    
                    new_status = 'Pending'
                    if total_payments >= bill_amount:
                        new_status = 'Paid'
                    elif total_payments > 0:
                        new_status = 'Partially Paid'
                        
                    c.execute("UPDATE bills SET status=? WHERE id=?", (new_status, bill_id))
                    
                conn.commit()
                conn.close()
                log_admin_activity(f"Deleted payment {payment_id} for bill {bill_id} ({vendor_company})")
                self._set_headers(200)
                self.wfile.write(json.dumps({'message': 'Payment deleted successfully'}).encode('utf-8'))
            else:
                conn.close()
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'Payment not found'}).encode('utf-8'))
                
        elif parsed_path.path.startswith('/api/admin/accounts-users/'):
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            username = urllib.parse.unquote(parsed_path.path[len('/api/admin/accounts-users/'):])
            conn = get_db_connection(ACCOUNTS_DB)
            c = conn.cursor()
            c.execute("DELETE FROM accounts_users WHERE username=?", (username,))
            conn.commit()
            conn.close()
            log_admin_activity(f"Deleted Accounts user: {username}")
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'User deleted'}).encode('utf-8'))
            
        elif parsed_path.path.startswith('/api/admin/vendors/'):
            if payload['role'] != 'admin':
                self._set_headers(403)
                self.wfile.write(json.dumps({'error': 'Forbidden'}).encode('utf-8'))
                return
                
            company = urllib.parse.unquote(parsed_path.path[len('/api/admin/vendors/'):])
            
            archive_dir = os.path.join(os.path.dirname(VENDOR_DATA_DIR), 'CG_Archive')
            if not os.path.exists(archive_dir):
                os.makedirs(archive_dir)
                
            db_path = get_vendor_db_path(company)
            
            if os.path.exists(db_path):
                import zipfile
                
                date_str = datetime.now().strftime('%Y-%m-%d')
                safe_company = "".join([c for c in company if c.isalpha() or c.isdigit()]).rstrip()
                zip_filename = f"{safe_company}_{date_str}.zip"
                zip_path = os.path.join(archive_dir, zip_filename)
                
                # We need to open connection read-only, or at least read files
                conn = get_db_connection(db_path)
                c = conn.cursor()
                files_to_delete = []
                try:
                    c.execute("SELECT file_path FROM bills WHERE file_path IS NOT NULL AND file_path != ''")
                    for row in c.fetchall():
                        files_to_delete.append(row[0])
                except sqlite3.OperationalError:
                    pass # Table doesn't exist yet
                conn.close()
                
                try:
                    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                        zf.write(db_path, os.path.basename(db_path))
                        for fpath in files_to_delete:
                            full_fpath = os.path.join(VENDOR_DATA_DIR, fpath)
                            if os.path.exists(full_fpath):
                                zf.write(full_fpath, fpath)
                except Exception as e:
                    print(f"Error creating zip archive: {e}")
                    
                # Delete the physical bill files
                for fpath in files_to_delete:
                    full_fpath = os.path.join(VENDOR_DATA_DIR, fpath)
                    if os.path.exists(full_fpath):
                        try:
                            os.remove(full_fpath)
                        except Exception as e:
                            print(f"Error deleting bill file {fpath}: {e}")
                            
                # Delete the specific database files
                try:
                    os.remove(db_path)
                    if os.path.exists(db_path + '-wal'):
                        os.remove(db_path + '-wal')
                    if os.path.exists(db_path + '-shm'):
                        os.remove(db_path + '-shm')
                except Exception as e:
                    print(f"Error deleting vendor db {db_path}: {e}")
                    
            # Finally, delete from main vendors.db
            v_conn = get_db_connection(VENDORS_DB)
            v_c = v_conn.cursor()
            v_c.execute("DELETE FROM vendors WHERE company=?", (company,))
            v_conn.commit()
            v_conn.close()
            
            log_admin_activity(f"Deleted vendor and archived data: {company}")
            
            self._set_headers(200)
            self.wfile.write(json.dumps({'message': 'Vendor deleted successfully'}).encode('utf-8'))
            
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({'error': 'Not found'}).encode('utf-8'))

def run(server_class=ThreadingHTTPServer, handler_class=SimpleAPIHandler, port=1512):
    init_db()
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting high-performance multithreaded server on port {port}...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
