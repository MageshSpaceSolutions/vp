// Auth Check
const currentUser = localStorage.getItem('vendorUser');
if (!currentUser) {
  window.location.href = 'index.html';
}

// Bills data cache with 30-second TTL to avoid redundant network requests
const _billsCache = { data: null, ts: 0, TTL: 30000 };
function _invalidateCache() { _billsCache.data = null; _billsCache.ts = 0; }


// Global XSS Mitigation
function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


// Navigation
function navigateTo(pageId) {
  // Update nav items
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
  });
  const navItem = document.querySelector(`.nav-item[data-page="${pageId}"]`);
  if (navItem) navItem.classList.add('active');

  // Update pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  const pageEl = document.getElementById(`page-${pageId}`);
  if (pageEl) pageEl.classList.add('active');

  // Update Header Title
  const titles = {
    'dashboard': 'Dashboard',
    'upload': 'Upload Bill',
    'payments': 'Payment Updates'
  };
  document.getElementById('headerTitle').textContent = titles[pageId] || pageId.charAt(0).toUpperCase() + pageId.slice(1);

  // Close sidebar on mobile
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.remove('open');
  }

  // If navigating to payments or dashboard, use cached data or refresh
  if (pageId === 'payments' || pageId === 'dashboard') {
    renderData();
  }
  if (pageId === 'banks') {
    loadBanks();
  }
}

// Sidebar Toggle (Mobile)
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// Format Currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
}

// Get Status Class
function getStatusClass(status) {
  switch (status.toLowerCase()) {
    case 'paid': return 'status-paid';
    case 'approved': return 'status-approved';
    default: return 'status-pending';
  }
}

// Fetch and Render Data
async function renderData() {
  const tableBody = document.getElementById('paymentsTableBody');
  const dashboardActivity = document.getElementById('dashboardActivity');
  const dashTotalCount = document.getElementById('dashTotalCount');
  const dashPendingCount = document.getElementById('dashPendingCount');
  const dashPendingAmt = document.getElementById('dashPendingAmt');
  const dashApprovedAmt = document.getElementById('dashApprovedAmt');
  const dashPaidAmt = document.getElementById('dashPaidAmt');
  const dashBalanceAmt = document.getElementById('dashBalanceAmt');
  
  const SKELETON_ROW = `<tr>${'<td><div style="height:14px;background:linear-gradient(90deg,#f0f0f0 25%,#e0e0e0 50%,#f0f0f0 75%);background-size:200% 100%;animation:shimmer 1.2s infinite;border-radius:4px;"></div></td>'.repeat(7)}</tr>`;
  if (tableBody) tableBody.innerHTML = SKELETON_ROW.repeat(3);
  if (dashboardActivity) dashboardActivity.innerHTML = '<div style="padding:16px;color:var(--text-muted)">Loading activity...</div>';

  // Serve from cache if still fresh
  const now = Date.now();
  if (_billsCache.data && (now - _billsCache.ts) < _billsCache.TTL) {
    _renderBillsData(_billsCache.data);
    return;
  }

  try {
    const token = localStorage.getItem('vendorToken');
    const response = await fetch(`${API_BASE}/bills?vendorCompany=${encodeURIComponent(currentUser)}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const vendorBills = await response.json();
    _billsCache.data = vendorBills;
    _billsCache.ts = Date.now();
    window.allBills = vendorBills;
    _renderBillsData(vendorBills);
  } catch (err) {
    console.error(err);
    if (tableBody) tableBody.innerHTML = '<tr><td colspan="5" style="color:var(--danger)">Failed to load data from server.</td></tr>';
  }
}

// Separated render logic so cache can call it directly
function _renderBillsData(vendorBills) {
  const tableBody = document.getElementById('paymentsTableBody');
  const dashboardActivity = document.getElementById('dashboardActivity');
  const dashTotalCount = document.getElementById('dashTotalCount');
  const dashPendingCount = document.getElementById('dashPendingCount');
  const dashPendingAmt = document.getElementById('dashPendingAmt');
  const dashApprovedAmt = document.getElementById('dashApprovedAmt');
  const dashPaidAmt = document.getElementById('dashPaidAmt');
  const dashBalanceAmt = document.getElementById('dashBalanceAmt');
  window.allBills = vendorBills;

    const filterSelect = document.getElementById('monthFilter');
    
    if (filterSelect && filterSelect.options.length <= 1) {
      const months = new Set();
      vendorBills.forEach(b => {
        if (b.date) months.add(b.date.substring(0, 7));
      });
      let optionsHtml = '<option value="all">All Time</option>';
      Array.from(months).sort().reverse().forEach(m => {
        optionsHtml += `<option value="${escapeHTML(m)}">${escapeHTML(m)}</option>`;
      });
      filterSelect.innerHTML = optionsHtml;
    }
    
    if (filterSelect && filterSelect.value !== 'all') {
      filteredBills = vendorBills.filter(b => b.date && b.date.startsWith(filterSelect.value));
    }
    
    if (tableBody) tableBody.innerHTML = '';
    if (dashboardActivity) dashboardActivity.innerHTML = '';
    
    let totalCount = filteredBills.length;
    let pendingCount = 0;
    let pendingAmt = 0;
    let approvedAmt = 0;
    let paidAmt = 0;

    filteredBills.forEach(payment => {
      let actualPaid = 0;
      if (payment.payments && payment.payments.length > 0) {
        actualPaid = payment.payments.reduce((sum, p) => sum + p.amount, 0);
      }
      paidAmt += actualPaid;

      if (payment.status === 'Pending') {
        pendingCount++;
        pendingAmt += payment.amount;
      } else if (payment.status === 'Approved' || payment.status === 'Partially Paid') {
        // Amount approved but not paid is Total - Actual Paid
        approvedAmt += (payment.amount - actualPaid);
      }
      
      // Determine columns
      let approvalStatus = payment.status === 'Rejected' ? 'Rejected' : (payment.status === 'Pending' ? 'Pending' : 'Approved');
      let paymentStatus = payment.status === 'Paid' ? 'Paid' : (actualPaid > 0 ? `Partially Paid (${formatCurrency(actualPaid)})` : 'Unpaid');
      
      // Populate Table
      if (tableBody) {
        const tr = document.createElement('tr');
        const downloadLink = payment.file_path ? `<a href="#" onclick="downloadSecureFile('${payment.file_path}', ''); return false;" style="color:var(--secondary); font-size:0.85rem; text-decoration:none; font-weight:500;">Download</a>` : '<span style="color:#aaa; font-size:0.85rem">No file</span>';
        
        const actionsHtml = `
          <div style="display:flex; gap:8px;">
            <button class="action-btn" style="background:var(--secondary); padding:4px 8px; font-size:0.75rem; border:none; border-radius:4px; color:white; cursor:pointer;" onclick="openVendorPaymentModal('${escapeHTML(payment.id)}')">Payments (${payment.payments ? payment.payments.length : 0})</button>
            <button class="action-btn" style="background:var(--danger); padding:4px 8px; font-size:0.75rem; border:none; border-radius:4px; color:white; cursor:pointer;" onclick="deleteBill('${escapeHTML(payment.id)}')">Delete</button>
          </div>
        `;

        tr.innerHTML = `
          <td>
            <strong>${escapeHTML(payment.id)}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Billed to: ${escapeHTML(payment.billed_company || 'N/A')}</div>
          </td>
          <td>${escapeHTML(payment.date)}</td>
          <td>${formatCurrency(payment.amount)}</td>
          <td><span class="status-badge ${getStatusClass(approvalStatus)}">${approvalStatus}</span></td>
          <td><span style="font-size:0.85rem; font-weight:600; color:var(--text-main);">${paymentStatus}</span></td>
          <td>${downloadLink}</td>
          <td>${actionsHtml}</td>
        `;
        tableBody.appendChild(tr);
      }

      // Populate Dashboard Activity (limit 3)
      if (dashboardActivity && filteredBills.indexOf(payment) < 3) {
        const div = document.createElement('div');
        div.style.padding = '16px';
        div.style.borderBottom = '1px solid var(--border)';
        div.style.display = 'flex';
        div.style.justifyContent = 'space-between';
        div.style.alignItems = 'center';
        
        div.innerHTML = `
          <div>
            <p style="font-weight: 500; margin-bottom: 4px;">${escapeHTML(payment.id)}</p>
            <p style="font-size: 0.85rem; color: var(--text-muted);">${escapeHTML(payment.date)}</p>
          </div>
          <div style="text-align: right;">
            <p style="font-weight: 600;">${formatCurrency(payment.amount)}</p>
            <span class="status-badge ${getStatusClass(approvalStatus)}" style="font-size: 0.75rem; padding: 2px 8px;">${approvalStatus}</span>
          </div>
        `;
        dashboardActivity.appendChild(div);
      }
    });

    let balanceAmt = pendingAmt + approvedAmt; // Balance to be paid
    
    if (dashTotalCount) dashTotalCount.textContent = totalCount;
    if (dashPendingCount) dashPendingCount.textContent = pendingCount;
    if (dashPendingAmt) dashPendingAmt.textContent = formatCurrency(pendingAmt);
    if (dashApprovedAmt) dashApprovedAmt.textContent = formatCurrency(approvedAmt);
    if (dashPaidAmt) dashPaidAmt.textContent = formatCurrency(paidAmt);
    if (dashBalanceAmt) dashBalanceAmt.textContent = formatCurrency(pendingAmt + approvedAmt);
    
  } catch (err) {
    console.error(err);
    if (tableBody) tableBody.innerHTML = '<tr><td colspan="5" style="color:var(--danger)">Failed to load data from server.</td></tr>';
  }
}

// Handle File Display
document.getElementById('fileUpload')?.addEventListener('change', function(e) {
  const fileName = e.target.files[0]?.name;
  if (fileName) {
    document.getElementById('fileNameDisplay').textContent = `Selected: ${fileName}`;
    document.getElementById('dropZone').style.borderColor = 'var(--accent)';
  }
});

// Handle Form Submission
async function handleUpload(event) {
  event.preventDefault();
  
  const id = document.getElementById('invoiceNo').value;
  const billedCompany = document.getElementById('billedCompany').value;
  const amount = parseFloat(document.getElementById('amount').value);
  const date = document.getElementById('date').value;
  const file = document.getElementById('fileUpload').files[0];

  if (!file) {
    alert('Please upload a file.');
    return;
  }

  const btn = event.target.querySelector('button');
  const originalText = btn.textContent;
  btn.textContent = 'Submitting...';
  
  const reader = new FileReader();
  reader.onload = async function() {
    const base64File = reader.result;

    const payload = {
      vendorId: currentUser,
      vendorCompany: localStorage.getItem('vendorCompany') || currentUser,
      id: id,
      billedCompany: billedCompany,
      amount: amount,
      date: date,
      fileData: base64File,
      fileName: file.name
    };

    try {
      const token = localStorage.getItem('vendorToken');
      const response = await fetch(`${API_BASE}/bills`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      
      btn.textContent = originalText;
      
      if (response.ok) {
        alert('Bill submitted successfully!');
        document.getElementById('uploadForm').reset();
        document.getElementById('fileNameDisplay').textContent = '';
        document.getElementById('dropZone').style.borderColor = 'var(--border)';
        navigateTo('dashboard');
      } else {
        alert(data.error || 'Failed to submit bill.');
      }
    } catch (err) {
      btn.textContent = originalText;
      alert('Could not connect to backend server.');
    }
  };
  reader.readAsDataURL(file);
}

// Delete Bill
async function deleteBill(billId) {
  if (!confirm(`Are you sure you want to delete bill ${billId}?`)) return;
  
  try {
    const token = localStorage.getItem('vendorToken');
    const response = await fetch(`${API_BASE}/bills/${billId}`, {
      method: 'DELETE',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ vendorCompany: currentUser })
    });
    if (response.ok) {
      alert('Bill deleted successfully.');
    renderData();
    _invalidateCache(); // Force fresh fetch after delete
    } else {
      const data = await response.json();
      alert(data.error || 'Failed to delete bill.');
    }
  } catch (err) {
    alert('Could not connect to backend server.');
  }
}

function openVendorPaymentModal(billId) {
  const bill = window.allBills.find(b => b.id === billId);
  if (!bill) return;

  let modal = document.getElementById('vendorPaymentModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'vendorPaymentModal';
    modal.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center; z-index:1000;';
    document.body.appendChild(modal);
  }
  
  let paymentsHtml = bill.payments && bill.payments.length > 0 
    ? bill.payments.map(p => `<tr><td>${p.date}</td><td>${formatCurrency(p.amount)}</td><td>${p.reference}</td></tr>`).join('')
    : `<tr><td colspan="3" style="text-align:center; color:var(--text-muted);">No payments recorded yet.</td></tr>`;

  modal.innerHTML = `
    <div style="background:var(--surface); padding:24px; border-radius:12px; width:500px; max-width:90%; max-height:90vh; overflow-y:auto;">
      <h3 style="margin-bottom:16px;">Payments for Invoice: ${escapeHTML(bill.id)}</h3>
      <table class="data-table">
        <thead><tr><th>Date</th><th>Amount</th><th>Ref / Txn ID</th></tr></thead>
        <tbody>${paymentsHtml}</tbody>
      </table>
      <div style="margin-top:20px; text-align:right;">
        <button class="btn-primary" onclick="document.getElementById('vendorPaymentModal').style.display='none'">Close</button>
      </div>
    </div>
  `;
  modal.style.display = 'flex';
}

// Initial render
document.addEventListener('DOMContentLoaded', () => {
  const usernameSpan = document.getElementById('headerUsername');
  const avatarDiv = document.getElementById('headerAvatar');
  if (usernameSpan && currentUser) {
    const comp = localStorage.getItem('vendorCompany') || currentUser;
    usernameSpan.textContent = comp;
    if (avatarDiv) avatarDiv.textContent = comp.charAt(0).toUpperCase();
  }
  renderData();
  loadBanks();
});

// Logout
function handleLogout() {
  localStorage.removeItem('vendorUser');
  localStorage.removeItem('vendorCompany');
  window.location.href = 'index.html';
}

// Change Password
async function handleVendorChangePassword(e) {
  e.preventDefault();
  const oldPass = document.getElementById('oldPassword').value;
  const newPass = document.getElementById('newPassword').value;
  const btn = document.getElementById('changePassBtn');
  
  btn.textContent = 'Updating...';
  
  try {
    const token = localStorage.getItem('vendorToken');
    const response = await fetch(`${API_BASE}/vendor/change-password`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ company: currentUser, old_password: oldPass, new_password: newPass })
    });
    
    const result = await response.json();
    btn.textContent = 'Update Password';
    
    if (response.ok) {
      document.getElementById('changePassSuccess').style.display = 'block';
      document.getElementById('changePassError').style.display = 'none';
      document.getElementById('oldPassword').value = '';
      document.getElementById('newPassword').value = '';
      setTimeout(() => { document.getElementById('changePassSuccess').style.display = 'none'; }, 3000);
    } else {
      document.getElementById('changePassError').textContent = result.error || 'Failed to update password.';
      document.getElementById('changePassError').style.display = 'block';
      document.getElementById('changePassSuccess').style.display = 'none';
    }
  } catch(err) {
    btn.textContent = 'Update Password';
    document.getElementById('changePassError').textContent = 'Could not connect to server.';
    document.getElementById('changePassError').style.display = 'block';
  }
}



// Bank JS
async function loadBanks() {
  const token = localStorage.getItem('vendorToken');
  const user = JSON.parse(localStorage.getItem('vendorUser'));
  const tBody = document.getElementById('banksTableBody');
  if (!tBody || !user) return;
  
  tBody.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';
  try {
    const response = await fetch(`${API_BASE}/banks?vendorCompany=${encodeURIComponent(user)}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const banks = await response.json();
    tBody.innerHTML = '';
    if (banks.length === 0) {
      tBody.innerHTML = '<tr><td colspan="4">No bank accounts added.</td></tr>';
      return;
    }
    banks.forEach(b => {
      const tr = document.createElement('tr');
      let badge = 'bg-pending';
      if (b.status === 'Verified') badge = 'bg-success';
      if (b.status === 'Rejected') badge = 'bg-danger';
      
      tr.innerHTML = `
        <td><strong>${escapeHTML(b.bank_name)}</strong></td>
        <td>${escapeHTML(b.account_number)}</td>
        <td>${escapeHTML(b.ifsc_code)}</td>
        <td><span class="status-badge ${badge}">${escapeHTML(b.status)}</span></td>
      `;
      tBody.appendChild(tr);
    });
  } catch (err) {
    tBody.innerHTML = '<tr><td colspan="4" style="color:var(--danger)">Failed to load banks</td></tr>';
  }
}

document.getElementById('chequeUpload')?.addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (file) {
    document.getElementById('chequeNameDisplay').textContent = file.name;
    const reader = new FileReader();
    reader.onload = function(evt) {
      document.getElementById('chequeUpload').setAttribute('data-base64', evt.target.result);
    };
    reader.readAsDataURL(file);
  }
});

async function submitBank(e) {
  e.preventDefault();
  const btn = document.getElementById('bankSubmitBtn');
  const err = document.getElementById('bankError');
  err.style.display = 'none';
  btn.textContent = 'Submitting...';
  btn.disabled = true;

  const user = JSON.parse(localStorage.getItem('vendorUser'));
  const fileInput = document.getElementById('chequeUpload');
  const fileData = fileInput.getAttribute('data-base64');
  
  const payload = {
    vendorCompany: user,
    bank_name: document.getElementById('bankName').value,
    account_number: document.getElementById('bankAccountNo').value,
    ifsc_code: document.getElementById('bankIFSC').value,
    fileName: fileInput.files[0].name,
    fileData: fileData
  };

  try {
    const token = localStorage.getItem('vendorToken');
    const response = await fetch(`${API_BASE}/banks`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    
    if (response.ok) {
      document.getElementById('bankModal').style.display = 'none';
      document.getElementById('bankForm').reset();
      document.getElementById('chequeNameDisplay').textContent = '';
      loadBanks();
    } else {
      const data = await response.json();
      err.textContent = data.error || 'Failed to submit';
      err.style.display = 'block';
    }
  } catch (error) {
    err.textContent = 'Network error';
    err.style.display = 'block';
  } finally {
    btn.textContent = 'Submit Bank';
    btn.disabled = false;
  }
}



// Secure Download
async function downloadSecureFile(filepath, company = '') {
  let tokenName = 'vendorToken';
  if (window.location.pathname.includes('admin')) tokenName = 'adminToken';
  if (window.location.pathname.includes('accounts')) tokenName = 'accountsToken';
  
  const token = localStorage.getItem(tokenName);
  
  try {
    const response = await fetch(`${API_BASE}/download?file=${filepath}&vendorCompany=${encodeURIComponent(company)}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filepath.split('/').pop();
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } else {
      alert('Failed to download file. You may not have permission.');
    }
  } catch (err) {
    alert('Network error while downloading.');
  }
}
