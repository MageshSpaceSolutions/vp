# CloudPanel Deployment Guide for Chandra Group Vendor Portal

This guide provides step-by-step instructions to deploy the Chandra Group Vendor Portal using **CloudPanel** (v2.x) on an AlmaLinux, Debian, or Ubuntu server.

CloudPanel runs Nginx as its primary web server. Since our application consists of a static HTML/CSS/JS frontend and a Python backend API, we will configure CloudPanel to serve the frontend directly, and run the Python backend under a Systemd service reverse-proxied by Nginx.

---

## Architecture Overview

*   **Frontend**: Served directly by **Nginx** via CloudPanel (Static Site).
*   **Backend**: Managed by **Systemd** running on port `1512`.
*   **Database**: **SQLite** (inside the `backend` folder, auto-initialized on first boot).
*   **Domain**: `portal.chandragroup.co` (or your chosen domain).

---

## Step 1: Create a site in CloudPanel

1. Log into your **CloudPanel Admin Area**.
2. Click **+ Add Site** and choose **Create a Reverse Proxy Site** (or **Create an HTML/JS Static Site**; a Reverse Proxy site is recommended as it allows configuring proxy settings easily).
3. Fill in the following details:
   *   **Domain Name**: `portal.chandragroup.co`
   *   **Reverse Proxy Port**: `1512` (the port our Python backend runs on)
   *   **Site User**: E.g., `clp-user` (take note of this username!)
   *   **Site User Password**: (Save this password securely)
4. Click **Create**.

---

## Step 2: Upload Project Files

1. Compress the contents of the `cp` directory into a `.zip` archive (containing `index.html`, `dashboard.html`, `css/`, `js/`, `pages/`, `backend/`, and `requirements.txt`).
2. Log into the server via **SSH** using your CloudPanel site user or upload via the CloudPanel File Manager.
3. Place and extract the zip file under the site's home directory:
   `/home/cloudpanel/htdocs/portal.chandragroup.co/`
4. Ensure files are owned by the site user:
   ```bash
   chown -R clp-user:clp-user /home/cloudpanel/htdocs/portal.chandragroup.co
   ```

---

## Step 3: Install Python Dependencies

Login via **SSH** as `root` (or the site user `clp-user`) and run:

```bash
cd /home/cloudpanel/htdocs/portal.chandragroup.co/backend
pip3 install -r ../requirements.txt
```

*(Note: The default `CG_Server.py` uses only Python standard libraries `sqlite3`, `http.server`, `smtplib`, etc., so dependencies are minimal. If your `requirements.txt` is blank or minimal, verify Python 3 is installed: `python3 --version`.)*

---

## Step 4: Configure the Systemd Service

To run the Python backend continuously in the background, configure a Systemd service.

1. Create a new service file as `root`:
   ```bash
   nano /etc/systemd/system/vendor-portal.service
   ```
2. Paste the following configuration (verify paths and the User):
   ```ini
   [Unit]
   Description=Vendor Portal Backend API
   After=network.target

   [Service]
   User=root
   WorkingDirectory=/home/cloudpanel/htdocs/portal.chandragroup.co/backend
   ExecStart=/usr/bin/python3 CG_Server.py
   Restart=always
   RestartSec=3

   [Install]
   WantedBy=multi-user.target
   ```
3. Save and close (Ctrl+O, Enter, Ctrl+X).
4. Start and enable the service:
   ```bash
   systemctl daemon-reload
   systemctl enable vendor-portal
   systemctl start vendor-portal
   ```
5. Verify it's running:
   ```bash
   systemctl status vendor-portal
   ```

---

## Step 5: Configure Nginx in CloudPanel

We need to configure Nginx to:
1. Serve the static frontend directly (for speed and efficiency).
2. Block direct web access to sensitive database/code files (`backend/*.db`, `secret.key`, etc.).
3. Proxy `/api/` traffic to the Systemd backend running on port `1512`.

1. Go to the **CloudPanel dashboard** for `portal.chandragroup.co`.
2. Click on the **Vhost** tab.
3. Replace or edit the Vhost configuration. Integrate the rules below inside your `server { ... }` block:

```nginx
# ==========================================
# CHANDRA GROUP PORTAL CUSTOM RULES
# ==========================================

# 1. Protect backend code, databases, and keys from public download
location ~ ^/backend/(.*)$ {
    deny all;
    return 404;
}

# 2. Protect raw vendor data files from direct listing/access
location ~ ^/Vendor\ Data/(.*)$ {
    deny all;
    return 404;
}

# 3. Route API requests to the Python Backend Service
location /api/ {
    proxy_pass http://127.0.0.1:1512;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    
    # Increase body size for file uploads (bills, cheques, etc.)
    client_max_body_size 10M;
}

# 4. Route frontend SPA routing / clean URLs
location / {
    try_files $uri $uri/ /pages/login.html;
}
```

4. Click **Save**. Nginx will reload automatically.

---

## Step 6: SSL Configuration (Optional & Recommended)

1. Under the site settings in **CloudPanel**, go to the **SSL/TLS** tab.
2. Click **Actions** -> **New Let's Encrypt Certificate**.
3. Select your domain and click **Create and Install**.
4. CloudPanel will automatically fetch, configure, and auto-renew the SSL certificate.

---

## Troubleshooting & Logs

*   **View backend logs**:
    ```bash
    journalctl -u vendor-portal -f
    ```
*   **Restart Backend**:
    ```bash
    systemctl restart vendor-portal
    ```
*   **Test local API connectivity**:
    ```bash
    curl -I http://localhost:1512/api/bills
    ```
    *(Should return HTTP 401 Unauthorized, confirming the backend is up and running).*
